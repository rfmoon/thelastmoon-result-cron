THELASTMOON RESULT BROWSER WORKER V2.2

PERBAIKAN V2.2
- Cron sekarang menulis log yang jelas:
  [CRON] trigger received
  [CRON] FINISHED OK
  atau [CRON] FAILED
- Scan menulis progress market dan jumlah result.
- POST API menulis progress tiap chunk.
- Jika Browser Run kena 429/rate limit:
  otomatis tunggu 25 detik lalu retry.
- Maksimal browser launch retry 3 kali.
- Jika Cron gagal, waitUntil dibuat reject supaya scheduled invocation
  terlihat FAILED di Cloudflare Logs.
- /health version sekarang v2.2-browser-run.
- Cron tetap setiap 10 menit.
- Observability Logs sudah ada di wrangler.toml.

CARA UPDATE GITHUB
Upload/replace SEMUA file ini ke repo:
thelastmoon-result-cron

Struktur:
package.json
wrangler.toml
README.txt
src/index.js

Commit ke main.
Cloudflare Builds akan deploy otomatis.

SECRET TETAP:
RESULT_API_KEY
RUN_TOKEN

BROWSER BINDING TETAP:
BROWSER

TEST:
GET /health

Target:
version: v2.2-browser-run
browserBinding: true
resultApiKeyConfigured: true
retry429: true

Setelah Cron berjalan:
Cloudflare -> Observability -> Logs
Cari:
[CRON]
[BROWSER]
[SCAN]
[API]

Jangan masukkan RESULT_API_KEY atau RUN_TOKEN ke source code.
